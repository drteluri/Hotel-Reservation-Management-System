g++ -o testauth Auth.cpp testauth.cpp -lcppunit 
./testauth

