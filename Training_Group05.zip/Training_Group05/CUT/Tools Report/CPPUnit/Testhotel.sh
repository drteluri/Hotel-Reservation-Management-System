g++ -o Testhotel hotel.cpp Testhotel.cpp -lcppunit 
./Testhotel

